
function createDataset(fields, constraints, sortFields) {

	//Conector TBC
	//Credenciais Auth Basic TBC
	var usuario = getAccess()[0];
	var pass = getAccess()[1];
	
	//Fim do Conector TBC padrao
	var NOME_SERVICO = "wsConsultaSQL";
	var CAMINHO_SERVICO = "com.totvs.WsConsultaSQL";
	var COLUNAS = new Array(
		"CODCOLIGADA",
		"CODCOMPONENTE",
		"CODMODALIDADE",
		"DESCRICAO",
		"CODGRUPOATIVIDADE"
	);
	var dataset = DatasetBuilder.newDataset();

	for (var i = 0; i < COLUNAS.length; i++) {
		dataset.addColumn(COLUNAS[i]);
	}
	try {
		var servico = ServiceManager.getService(NOME_SERVICO);
		log.info("servico " + servico)
		var instancia = servico.instantiate(CAMINHO_SERVICO);
		log.info("instancia " + instancia)
		var ws = instancia.getRMIwsConsultaSQL();
		log.info("ws " + ws)
		var serviceHelper = servico.getBean();
		log.info("serviceHelper " + serviceHelper)
		var authService = serviceHelper.getBasicAuthenticatedClient(ws, "com.totvs.IwsConsultaSQL", usuario, pass);
		log.info("authService " + authService)
		var CODCOLIGADA,CODCOMPONENTE,DESCRICAO;
		var PARAMS;
		if (constraints != null) {
			for (var i = 0; i < constraints.length; i++) {
				if (constraints[i].fieldName == "CODCOLIGADA") {
					CODCOLIGADA = constraints[i].initialValue
				}
				if (constraints[i].fieldName == "CODCOMPONENTE") {
					CODCOMPONENTE = constraints[i].initialValue
				}
				if (constraints[i].fieldName == "DESCRICAO") {
					DESCRICAO = constraints[i].initialValue
				}
			}
		}
	    PARAMS = "CODCOLIGADA=" + CODCOLIGADA + ";CODCOMPONENTE=" + CODCOMPONENTE + ";DESCRICAO=" + DESCRICAO;
		log.info("PARAMS " + PARAMS);
		var result = authService.realizarConsultaSQL("CJ.FLUIG.0003", 0, "S", PARAMS);
		log.info("result " + result);
		var JSONObj = org.json.XML.toJSONObject(result);
		var dados = JSONObj.get("NewDataSet").get("Resultado");

		if (dados.isNull(0)) {
			row = dados;
			dataset.addRow(new Array(
			    row.has("CODCOLIGADA") ? row.get("CODCOLIGADA") : "",
			    row.has("CODCOMPONENTE") ? row.get("CODCOMPONENTE") : "",
			    row.has("CODMODALIDADE") ? row.get("CODMODALIDADE") : "",
			    row.has("DESCRICAO") ? row.get("DESCRICAO") : "",
			    row.has("CODGRUPOATIVIDADE") ? row.get("CODGRUPOATIVIDADE") : ""
			));
		} else
			for (var i = 0; i < dados.length(); i++) {
				var registro = dados.get(i);
				dataset.addRow(new Array(
					registro.get("CODCOLIGADA"),
					registro.get("CODCOMPONENTE"),
					registro.get("CODMODALIDADE"),
					registro.get("DESCRICAO"),
					registro.get("CODGRUPOATIVIDADE")
				));

			}
		return dataset;

	} catch (e) {
		return getDefaultError(e.toString());

	}

}

function getDefaultError(error) {

	var dsError = DatasetBuilder.newDataset();

	dsError.addColumn('ERROR');

	dsError.addRow(new Array(error));

	return dsError;
	
}

function getAccess() {
	try {
	  var response = new Array();
	  var dataset = DatasetFactory.getDataset("dsTBCConnector", null, null, null);
	  var u = dataset.getValue(0, "user");
	  var p = dataset.getValue(0, "pass");
	  response.push(u, p);
	  return response;
	} catch (e) {
	  throw "getAccess / " + e.toString();
	}
  }

