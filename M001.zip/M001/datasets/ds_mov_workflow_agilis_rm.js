function createDataset(fields, constraints, sortFields) {
  try {
    var codAtendimento,codMotivo,fluxoEtapa,proxEtapa,codColigada,codLocal;

    if (constraints != null) {
			for (var i = 0; i < constraints.length; i++) {
				if (constraints[i].fieldName == "CODATENDIMENTO") {
					codAtendimento = constraints[i].initialValue
				}
				if (constraints[i].fieldName == "CODCOLIGADA") {
					codColigada = constraints[i].initialValue
				}
				if (constraints[i].fieldName == "CODMOTIVO") {
					codMotivo = constraints[i].initialValue
				}
        if (constraints[i].fieldName == "FLUXOETAPA") {
					fluxoEtapa = constraints[i].initialValue
				}
        if (constraints[i].fieldName == "PROXETAPA") {
					proxEtapa = constraints[i].initialValue
				}
        if (constraints[i].fieldName == "CODLOCAL") {
					codLocal = constraints[i].initialValue
				}
			}
		}

    return advanceService(codAtendimento,codMotivo,fluxoEtapa,proxEtapa,codColigada,codLocal);

  } catch (e) {
    return getDefaultError(e.toString());
  }
}

function advanceService(codAtendimento,codMotivo,fluxoEtapa,proxEtapa,codColigada,codLocal){
  try {

    var XML = '<CRMAvancarEtapaAtendimentoParamsProc xmlns="http://www.totvs.com.br/RM/" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:z="http://schemas.microsoft.com/2003/10/Serialization/" z:Id="i1">';
          XML += '<ActionModule xmlns="http://www.totvs.com/">H</ActionModule>';
          XML += '<ActionName xmlns="http://www.totvs.com/">CRMAtendimentoAcoesAvancarEtapaAction</ActionName>';
          XML += '<CodUsuario xmlns="http://www.totvs.com/">mestre</CodUsuario>';
          XML += '<Context xmlns="http://www.totvs.com/" xmlns:a="http://www.totvs.com.br/RM/" z:Id="i2">';
          XML += '<a:_params xmlns:b="http://schemas.microsoft.com/2003/10/Serialization/Arrays">';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$EXERCICIOFISCAL</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:int">'+1+'</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODLOCPRT</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:int">'+ -1 +'</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODTIPOCURSO</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:int">'+1+'</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$EDUTIPOUSR</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">'+ -1 +'</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODUNIDADEBIB</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:int">'+ -1 +'</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODCOLIGADA</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:int">'+1+'</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$RHTIPOUSR</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">'+ -1 +'</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODIGOEXTERNO</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">'+ -1 + '</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODSISTEMA</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">S</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODUSUARIOSERVICO</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string" />';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODUSUARIO</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">mestre</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>'; 
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$IDPRJ</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:int">'+ -1 + '</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CHAPAFUNCIONARIO</b:Key>'
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">'+ -1 + '</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '<b:KeyValueOfanyTypeanyType>';
          XML += '<b:Key xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:string">$CODFILIAL</b:Key>';
          XML += '<b:Value xmlns:c="http://www.w3.org/2001/XMLSchema" i:type="c:int">'+1+'</b:Value>';
          XML += '</b:KeyValueOfanyTypeanyType>';
          XML += '</a:_params>';
          XML += '<a:Environment>DotNet</a:Environment>';
          XML += '</Context>';
          XML += '<PrimaryKeyList xmlns="http://www.totvs.com/" xmlns:a="http://schemas.microsoft.com/2003/10/Serialization/Arrays">';
          XML += '<a:ArrayOfanyType>'
          XML += '<a:anyType xmlns:b="http://www.w3.org/2001/XMLSchema" i:type="b:short">'+codColigada+'</a:anyType>';
          XML += '<a:anyType xmlns:b="http://www.w3.org/2001/XMLSchema" i:type="b:int">'+codLocal+'</a:anyType>';
          XML += '<a:anyType xmlns:b="http://www.w3.org/2001/XMLSchema" i:type="b:int">'+codAtendimento+'</a:anyType>';
          XML += '</a:ArrayOfanyType>';
          XML += '</PrimaryKeyList>';
          XML += '<PrimaryKeyNames xmlns="http://www.totvs.com/" xmlns:a="http://schemas.microsoft.com/2003/10/Serialization/Arrays">';
          XML += '<a:string>CODCOLIGADA</a:string>';
          XML += '<a:string>CODLOCAL</a:string>';
          XML += '<a:string>CODATENDIMENTO</a:string>';
          XML += '</PrimaryKeyNames>';
          XML += '<PrimaryKeyTableName xmlns="http://www.totvs.com/">HAtendimentoBase</PrimaryKeyTableName>';
          XML += '<ProcessName xmlns="http://www.totvs.com/">Avançar etapa</ProcessName>';
          XML += '<UserName xmlns="http://www.totvs.com/">mestre</UserName>'
          XML += '<CodigoAtendente>'+ -1 +'</CodigoAtendente>';
          XML += '<CodigoMotivo>'+codMotivo+'</CodigoMotivo>';
          XML += '<CodigoProximaEtapa>'+proxEtapa+'</CodigoProximaEtapa>';
          XML += '<ColigadaAtendente>'+ -1 +'</ColigadaAtendente>';
          XML += '<ColigadaContexto>'+codColigada+'</ColigadaContexto>';
          XML += '<IdFluxoDeEtapas>'+fluxoEtapa+'</IdFluxoDeEtapas>';
          XML += '<JustificativaAvanco />';
          XML += '<SolucaoAvanco />';
          XML += '<UsuarioContexto>mestre</UsuarioContexto>';
          XML += '</CRMAvancarEtapaAtendimentoParamsProc>';
          
    log.info("######## XML: ")
    log.info(XML)

    var usuario = getAccess()[0];
    var senha = getAccess()[1];
    var NOME_SERVICO = "wsProcess";
    var CAMINHO_SERVICO = "com.totvs.WsProcess"; 
    var servico = ServiceManager.getServiceInstance(NOME_SERVICO);	
    var serviceHelper = servico.getBean();
    var instancia = servico.instantiate(CAMINHO_SERVICO);
    var ws = instancia.getRMIwsProcess(); 
    var authenticatedService = serviceHelper.getBasicAuthenticatedClient(ws, "com.totvs.IwsProcess",usuario, senha);
    
    log.error(ws);

    var response = authenticatedService.executeWithXmlParamsAsync("CRMAvancarEtapaAtendimento", XML);
    if ((response != null) && (response.indexOf("===") != -1)){
    	var msgErro = response.substring(0, response.indexOf("==="));
    	throw msgErro;
	}
    
    log.info("######## response: ")
    log.error(response);
    
    var dataset = DatasetBuilder.newDataset();
	dataset.addColumn("result");
	dataset.addRow(
		new Array(
			response
		)
	);
	
	log.info("RESULT MOV AGILIS: " + dataset);
    return dataset;
  } catch (e) {
    return getDefaultError(e.toString());
  }
}

//DataSet ERRO
function getDefaultError(error) {

	var dsError = DatasetBuilder.newDataset();

	dsError.addColumn('ERROR');

	dsError.addRow(new Array(error));

	return dsError;
	
}

//Acesso TBC
function getAccess() {
    try {
      var response = new Array();
      var dataset = DatasetFactory.getDataset("dsTBCConnector", null, null, null);
      var u = dataset.getValue(0, "user");
      var p = dataset.getValue(0, "pass");
      response.push(u, p);
      return response;
    } catch (e) {
      throw "getAccess / " + e.toString();
    }
  }
