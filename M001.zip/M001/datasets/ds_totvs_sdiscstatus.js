/***********************************************************************************************
 * @author 		TBNE - Angelo Barcelos - Desenvolvedor FLUIG angelo.barcelos@totvs.com.br
 * @data   		02/01/2023
 * @Versao RM   12.1.32
 * @Descricao	Listar Disciplinas
 ***********************************************************************************************/


/* Versao RM - Habilitar apos cadastrar os servicos RM modelo usando Host RM 8051*/
function createDataset(fields, constraints, sortFields) {

	//Conector TBC
	//Credenciais Auth Basic TBC
	var usuario = getAccess()[0];
	var pass = getAccess()[1];
	
	//Fim do Conector TBC padrao
	var NOME_SERVICO = "wsConsultaSQL";
	var CAMINHO_SERVICO = "com.totvs.WsConsultaSQL";
	var COLUNAS = new Array(
		"CODSTATUS",
		"CODRESULT"
	);
	var dataset = DatasetBuilder.newDataset();

	for (var i = 0; i < COLUNAS.length; i++) {
		dataset.addColumn(COLUNAS[i]);
	}
	try {
		var servico = ServiceManager.getService(NOME_SERVICO);
		log.info("servico " + servico)
		var instancia = servico.instantiate(CAMINHO_SERVICO);
		log.info("instancia " + instancia)
		var ws = instancia.getRMIwsConsultaSQL();
		log.info("ws " + ws)
		var serviceHelper = servico.getBean();
		log.info("serviceHelper " + serviceHelper)
		var authService = serviceHelper.getBasicAuthenticatedClient(ws, "com.totvs.IwsConsultaSQL", usuario, pass);
		log.info("authService " + authService)
		// codcoligada=1;idhabilitacaofilial=2763
		var CODCOLIGADA;
		var CODTIPOCURSO;
		var PARAMS;
		if (constraints != null) {
			for (var i = 0; i < constraints.length; i++) {
				if (constraints[i].fieldName == "CODCOLIGADA") {
					CODCOLIGADA = constraints[i].initialValue
				}
				if (constraints[i].fieldName == "CODTIPOCURSO") {
					CODTIPOCURSO = constraints[i].initialValue
				}

			}
		}
	    //PARAMS = "CODCOLIGADA=" + CODCOLIGADA + ";CODTIPOCURSO=" + CODTIPOCURSO;
	    PARAMS = "CODCOLIGADA=1" + ";CODTIPOCURSO=1";
		log.info("PARAMS " + PARAMS);
		var result = authService.realizarConsultaSQL("IMR.FLUIG.3", 0, "S", PARAMS);
		log.info("result " + result);
		var JSONObj = org.json.XML.toJSONObject(result);
		var dados = JSONObj.get("NewDataSet").get("Resultado");

		if (dados.isNull(0)) {
			row = dados;
			dataset.addRow(new Array(
			    row.has("CODSTATUS") ? row.get("CODSTATUS") : "",
			    row.has("CODRESULT") ? row.get("CODRESULT") : ""
			));
		} else
			for (var i = 0; i < dados.length(); i++) {
				var registro = dados.get(i);
				dataset.addRow(new Array(
					registro.get("CODSTATUS"),
					registro.get("CODRESULT")
				));

			}
		return dataset;

	} catch (e) {
		return getDefaultError(e.toString());

	}

}

function getDefaultError(error) {

	var dsError = DatasetBuilder.newDataset();

	dsError.addColumn('ERROR');

	dsError.addRow(new Array(error));

	return dsError;
	
}

function getAccess() {
	try {
	  var response = new Array();
	  var dataset = DatasetFactory.getDataset("dsTBCConnector", null, null, null);
	  var u = dataset.getValue(0, "user");
	  var p = dataset.getValue(0, "pass");
	  response.push(u, p);
	  return response;
	} catch (e) {
	  throw "getAccess / " + e.toString();
	}
  }


/* TBC via IIS
function createDataset(fields, constraints, sortFields) {

//Credenciais Auth Basic TBC
var usuario = getAccess()[0];
var pass    = getAccess()[1];
var vBase64 = new org.apache.commons.codec.binary.Base64();
var senha   = new java.lang.String(vBase64.decodeBase64(pass.getBytes()));


//Fim do Conector TBC padrao
var NOME_SERVICO = "wsConsultaSQL";
var CAMINHO_SERVICO = "br.com.totvs.www.br.WsConsultaSQL";
var COLUNAS = new Array(
  "CODDISC",
  "DISCIPLINA"
 );
var dataset = DatasetBuilder.newDataset();

for (var i = 0; i < COLUNAS.length; i++) {
  dataset.addColumn(COLUNAS[i]);
}

try {
 
   //Chamada do Web Service via TBC IIS realizarConsultaSQLAuth
    var serviceHelper  = ServiceManager.getService(NOME_SERVICO);
	var serviceLocator = serviceHelper.instantiate(CAMINHO_SERVICO);
	var service = serviceLocator.getwsConsultaSQLSoap();
	if (constraints != null) {
        for (var i = 0; i < constraints.length; i++) {
          if (constraints[i].fieldName == "CODCOLIGADA") {
        	  CODCOLIGADA = constraints[i].initialValue
          }
          if (constraints[i].fieldName == "IDHABILITACAOFILIAL") {
        	  IDHABILITACAOFILIAL = constraints[i].initialValue
          }
          var PARAMS = "CODCOLIGADA=" + CODCOLIGADA+";+IDHABILITACAOFILIAL="+IDHABILITACAOFILIAL;
        }
     }
	var result = service.realizarConsultaSQLAuth(
			'IMR.FLUIG.1', 
			'0', 
			'S', 
			String(usuario), 
			String(senha), 
			PARAMS
	);

  var JSONObj = org.json.XML.toJSONObject(result);
  var dados = JSONObj.get("NewDataSet").get("Resultado");

  for (var i = 0; i < dados.length(); i++) {
    var registro = dados.get(i);
    dataset.addRow(new Array(
      registro.get("CODDISC"),
      registro.get("DISCIPLINA")
    ));
   
  }
  return dataset;
} catch (e) {
  if (e == null)
    e = "Erro desconhecido; verifique o log do AppServer";
  var mensagemErro = "Erro na comunicação com o app (linha: " + e.lineNumber + "): " + e;
  log.error(mensagemErro);
  log.info(mensagemErro);
  dataset.addColumn("CODDISC");
  dataset.addColumn("DISCIPLINA");
  dataset.addRow(new Array(-1, mensagemErro));
}
}

*/
/* Para testes 
 function createDataset(fields, constraints, sortFields) {
	//Dataset Fake pra Testes
	 var dataset = DatasetBuilder.newDataset();
	 dataset.addColumn("CODDISC");
	 dataset.addColumn("DISCIPLINA");
	 dataset.addRow(new Array("00897.060", "EXERCICIOS PERSONALIZADOS"));
	 dataset.addRow(new Array("00898.061", "EXERCICIOS PERSONALIZADOS II"));
	 
	 return dataset

}*/


//Acesso TBC
