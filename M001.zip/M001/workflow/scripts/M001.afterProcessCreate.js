function afterProcessCreate(processId){
	hAPI.setCardValue("numProcessoFluig",processId);
}