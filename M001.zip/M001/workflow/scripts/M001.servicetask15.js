function servicetask15(attempt, message) {
  try {
    var camposForm = new java.util.HashMap();
    var dataSetXml = ""
    camposForm = hAPI.getCardData(getValue("WKNumProces"));
    
    saveRecordDiscDestino(camposForm, dataSetXml);
  }catch (e) {
    throw e.toString();
  }
}

function saveRecordDiscDestino(camposForm, dataSetXml) {
  var usuario = getAccess()[0];
  var pass    = getAccess()[1];

  var NOME_SERVICO = "wsDataServer";
  var CAMINHO_SERVICO = "com.totvs.WsDataServer";

  var servico = ServiceManager.getServiceInstance(NOME_SERVICO);

  var serviceHelper = servico.getBean();
  var instancia = servico.instantiate(CAMINHO_SERVICO);

  var ws = instancia.getRMIwsDataServer();

  var authenticatedService = serviceHelper.getBasicAuthenticatedClient(ws, "com.totvs.IwsDataServer", usuario, pass);

  log.info("########## Iniciando montagem do XML ...");

  var arrayIntegraçao = new Array();
  
  dataSetXml += "<EduInscAlunoAtvOfertadaData> ";
  			dataSetXml += "<sAtividadeAluno> ";
	        dataSetXml += ValidaCampo("CODCOLIGADA", 					camposForm.get("codColigada"));
	        dataSetXml += ValidaCampo("IDATIVIDADE", 					"-1");
	        dataSetXml += ValidaCampo("RA", 							camposForm.get("ra"));
	        dataSetXml += ValidaCampo("CODFILIAL", 						camposForm.get("codFilial"));
	        dataSetXml += ValidaCampo("IDPERLET", 						camposForm.get("idPerlet"));
	        dataSetXml += ValidaCampo("IDHABILITACAOFILIAL", 			camposForm.get("idHabilitacaoFilial"));
	        dataSetXml += ValidaCampo("CARGAHORARIA", 					camposForm.get("cargaHoraria"));
	        dataSetXml += ValidaCampo("CARGAHORARIAATV", 				camposForm.get("cargaHorariaatv"));
	        dataSetXml += ValidaCampo("CODCOMPONENTE", 					camposForm.get("codComponente"));
	        dataSetXml += ValidaCampo("CODTIPOPART", 					camposForm.get("codTipoParticipacao"));
	        dataSetXml += ValidaCampo("CODMODALIDADE", 					camposForm.get("codModalidade"));
	        dataSetXml += ValidaCampo("CODINST", 						camposForm.get("codInstituicao"));
	        dataSetXml += ValidaCampo("OBSERVACAO", 					camposForm.get("observacoes"));
	        dataSetXml += ValidaCampo("CREDITOS", 						camposForm.get("creditos"));
	        dataSetXml += ValidaCampo("CONVENIO", 						camposForm.get("convenio"));
	        dataSetXml += ValidaCampo("CUMPRIUATIVIDADE", 				"S");
	        dataSetXml += ValidaCampo("DATA", 							camposForm.get("dataConclusao"));
	        dataSetXml += ValidaCampo("DATAFIM", 						camposForm.get("datafim"));
	        dataSetXml += ValidaCampo("DATAINICIO", 					camposForm.get("datainicio"));
	        dataSetXml += ValidaCampo("DESCRICAO", 						camposForm.get("descricao"));
	        dataSetXml += ValidaCampo("DOCUMENTACAOENTREGUE", 			"S");
	        /*dataSetXml += ValidaCampo("IDATIVIDADE", 					"");*/
	        dataSetXml += ValidaCampo("INSCRICAOCONFIRMADA", 			"S");
	        dataSetXml += ValidaCampo("LOCAL", 							camposForm.get("localAtividade"));
        dataSetXml += "</sAtividadeAluno> ";
        dataSetXml += "</EduInscAlunoAtvOfertadaData> ";
    
    arrayIntegraçao.push(dataSetXml);

      
  log.info("######## dataSetXml LIDO: ########" + dataSetXml);
      
  var codCol 		= camposForm.get("codColigada");
  var codFil 		= camposForm.get("codFilial");
  var codTipCurso 	= camposForm.get("codTipoCurso");

  //Cria contexto RM
    var rmsContext = "CODCOLIGADA="+codCol+";CODFILIAL="+codFil+";CODTIPOCURSO="+codTipCurso+";CODSISTEMA=S;CODUSUARIO="+usuario; 
    
  var result = authenticatedService.saveRecord("EduInscAlunoAtvOfertadaData", arrayIntegraçao[0], rmsContext);
  log.info("################ result integracao: " + result);

  if ((result != null) && (result.indexOf("===") != -1)){
      var msgErro = result.substring(0, result.indexOf("==="));
        
      throw msgErro;
    }
}

//Acesso TBC
function getAccess() {
  try {
    var response = new Array();
    var dataset = DatasetFactory.getDataset("dsTBCConnector", null, null, null);
    var u = dataset.getValue(0, "user");
    var p = dataset.getValue(0, "pass");
    response.push(u, p);
    return response;
  } catch (e) {
    throw "getAccess / " + e.toString();
  }
}


//IIS
function getWebService(Usuario, Senha) {
	
	  var Nome_Servico = "wsDataServer";
	  var Caminho_Servico = "br.com.totvs.br.WsDataServer";
	  var dataServerService = ServiceManager.getServiceInstance(Nome_Servico);
	  if (dataServerService == null) {
	    throw "Servico nao encontrado: " + Nome_Servico;
	  }
	  
	  var serviceLocator = dataServerService.instantiate(Caminho_Servico);
	  if (serviceLocator == null) {
	    throw "Instancia do servico nao encontrada: " + Nome_Servico + " - " + Caminho_Servico;
	  }
	  var service = serviceLocator.getWsDataServerSoap();
	  if (service == null) {
	    throw "Instancia do dataserver do invalida: " + Nome_Servico + " - " + Caminho_Servico;
	  }
	  var serviceHelper = dataServerService.getBean();
	  if (serviceHelper == null) {
	    throw "Instancia do service helper invalida: " + Nome_Servico + " - " + Caminho_Servico;
	  }
	  var authService = serviceHelper.getBasicAuthenticatedClient(service, "br.com.totvs.br.WsDataServerSoap", Usuario, Senha);
	  if (serviceHelper == null) {
	    throw "Instancia do auth service invalida: " + Nome_Servico + " - " + Caminho_Servico;
	  }
	  return authService;
	}



//Host RM 8051
function getWebService_HostRM(Usuario, Senha) {
  var Nome_Servico = "wsDataServer";
  var Caminho_Servico = "com.totvs.WsDataServer";
  var dataServerService = ServiceManager.getServiceInstance(Nome_Servico);
  if (dataServerService == null) {
    throw "Servico nao encontrado: " + Nome_Servico;
  }
  var serviceLocator = dataServerService.instantiate(Caminho_Servico);
  if (serviceLocator == null) {
    throw "Instancia do servico nao encontrada: " + Nome_Servico + " - " + Caminho_Servico;
  }
  var service = serviceLocator.getRMIwsDataServer();
  if (service == null) {
    throw "Instancia do dataserver do invalida: " + Nome_Servico + " - " + Caminho_Servico;
  }
  var serviceHelper = dataServerService.getBean();
  if (serviceHelper == null) {
    throw "Instancia do service helper invalida: " + Nome_Servico + " - " + Caminho_Servico;
  }
  var authService = serviceHelper.getBasicAuthenticatedClient(service, "com.totvs.IwsDataServer", Usuario, Senha);
  if (serviceHelper == null) {
    throw "Instancia do auth service invalida: " + Nome_Servico + " - " + Caminho_Servico;
  }
  return authService;
}

function dcReadView(dataservername, context, usuario, senha, filtro) {
  var authService = getWebService(usuario, senha);
  var viewData = new String(authService.readView(dataservername, filtro, context));
  return viewData;
}

function dcReadRecord(dataservername, context, usuario, senha, primaryKey) {
  var authService = getWebService(usuario, senha);
  try {
    var recordData = new String(authService.readRecord(dataservername, primaryKey, context));
  } catch (e) {
    var recordData = new String(authService.getSchema(dataservername, context));
  }
  return recordData;
}

function dcSaveRecord(dataservername, context, usuario, senha, xml) {
  var authService = getWebService(usuario, senha);
  var pk = new String(authService.readRecord(dataservername, xml, context));
  return pk;
}

function parseConstraints(constraints, filterRequired) {
  var result = [];
  result.context = "";
  var filter = "";
  for (con in constraints) {
    var fieldName = con.getFieldName().toUpperCase();
    if (fieldName == "RMSCONTEXT") {
      result.context = con.getInitialValue();
      continue;
    }
    filter += "(";
    if (fieldName == "RMSFILTER") {
      filter += con.getInitialValue();
    } else {
      if (con.getInitialValue() == con.getFinalValue() || isEmpty(con.getFinalValue())) {
        filter += con.getFieldName();
        var isLike = false;
        switch (con.getConstraintType()) {
          case ConstraintType.MUST:
            filter += " = ";
            break;
          case ConstraintType.MUST_NOT:
            filter += " = ";
            break;
          case ConstraintType.SHOULD:
            filter += " LIKE ";
            isLike = true;
            break;
          case ConstraintType.SHOULD_NOT:
            filter += " NOT LIKE ";
            isLike = true;
            break;
        }
        filter += getFormattedValue(con.getInitialValue(), isLike);
      } else {
        filter += con.getFieldName();
        filter += " BETWEEN ";
        filter += getFormattedValue(con.getInitialValue(), false);
        filter += " AND ";
        filter += getFormattedValue(con.getFinalValue(), false);
      }
    }
    filter += ") AND ";
  }
  if (filter.length == 0) {
    if (filterRequired) {
      filter = "1=1";
    } else {
      filter = "1=1";
    }
  } else
    filter = filter.substring(0, filter.length - 5);
  result.filter = filter;
  return result;
}

function isEmpty(str) {
  return (!str || 0 === str.length);
}

function getFormattedValue(value, isLike) {
  if (isLike) {
    return "'%" + value + "%'";
  } else {
    return "'" + value + "'";
  }
}

function getXMLFromString(xmlString) {
  var factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
  var parser = factory.newDocumentBuilder();
  var is = new org.xml.sax.InputSource();
  is.setCharacterStream(new java.io.StringReader(xmlString));
  return parser.parse(is);
}

function checkIsPK(result, qtd) {
  var lines = result.split('\r');
  if (lines.length == 1) {
    var pk = result.split(';');
    if (pk.length == qtd)
      return;
  }
  throw result;
}

function ChekExist(result) {
  var lines = result.split('\r');
  if (lines.length > 1)
    return true
  else
    return false;
}

function ValidaCampo(campo, valor) {
  log.info("ENTROU VALIDACAMPO ---->" + campo + " " + valor);
  if ((valor != null) && (valor != "")) {
    log.info("ENTROU NO IF VALIDACAMPO ---->" + campo + " " + valor);
    return "<" + campo + ">" + valor + "</" + campo + "> ";
  } else
    return "";
}

function isEmpty(str) {
  return (!str || 0 === str.length);
}