function enableFields(form){
	var atividade = parseInt(getValue("WKNumState"));
	var disciplinas = form.getChildrenIndexes("tabelaAproveitamento");
	
}