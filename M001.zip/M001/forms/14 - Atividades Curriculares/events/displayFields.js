function displayFields(form,customHTML){
	var atividade = parseInt(getValue("WKNumState"));
    form.setShowDisabledFields(true);
    form.setHidePrintLink(true);

    customHTML.append("<script>");
    customHTML.append("        function getWKNumState(){ return " + atividade + "};");
    customHTML.append("</script>");
    customHTML.append("<script>function getNumProces(){ return " + getValue("WKNumProces") + "; }</script>");
    customHTML.append("<script>function getWKUserc() { return '" + fluigAPI.getUserService().getCurrent().getFullName() + "'; }</script>");
	

}