function validateForm(form){
	var atividade = parseInt(getValue("WKNumState"));
	var proxAtividade = parseInt(getValue("WKNextState"));
	var Errors = new Array();
	
	
	if (Errors.length > 0) {
		var mensagem = "";
		for (var i = 0; i < Errors.length; i++) {
			mensagem += "- " + Errors[i] + "<br>";
		}
		throw "Os campos destacados com (*) são destacados com preenchimento obrigatório! <br> " + mensagem + "<br>";
	}
}
