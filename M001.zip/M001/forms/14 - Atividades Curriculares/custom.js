var M001 = {
	retornaMensagem: function (title, msg, tipo, time) {
        FLUIGC.toast({
            title: title,
            message: msg,
            type: tipo,
            timeout: time
        })
    },
    
    carregaCodModalidade: function(){
    	
	    try {
	    	var codcoligada = $('#codColigada').val();
	    	var codComponente = $('#codComponente').val();
	    	var modalidade = $('#modalidade').val();
	        if (codcoligada == "" || codcoligada == null || codcoligada == undefined)
	            throw "É necessário informar o código da coligada antes para realizar a busca.";
	        if (codComponente == "" || codComponente == null || codComponente == undefined)
	            throw "É necessário informar o código do componente antes para realizar a busca.";
	        if (modalidade == "" || modalidade == null || modalidade == undefined)
	            throw "É necessário informar modalidade antes para realizar a busca.";

	        var c1 = DatasetFactory.createConstraint('CODCOLIGADA', codcoligada, codcoligada, ConstraintType.MUST);
	        var c2 = DatasetFactory.createConstraint('CODCOMPONENTE', codComponente, codComponente, ConstraintType.MUST);
	        var c3 = DatasetFactory.createConstraint('DESCRICAO',modalidade,modalidade,ConstraintType.MUST)
	        var c = new Array(c1,c2,c3);

	        var dsModalidade = DatasetFactory.getDataset('ds_totvs_smodalidade', null, c, null);

	        if (undefined == dsModalidade.values || typeof dsModalidade.values == "undefined") {        
	            throw "Nenhum resultado encontrado.";
	        }
	        else {
	            for (var i = 0; i < dsModalidade.values.length; i++) {
	                $('#codModalidade').val(dsModalidade.values[i].CODMODALIDADE.toString())
	            }
	        }
	    } catch (e) {
	    	/*M001.retornaMensagem("ERRO > carregaCodModalidade > ", e.toString(), "warning", 6000);*/
	    	console.log("carregaCodModalidade > " + e.toString());
	    }
    },
	
    init:function(){
    	M001.carregaCodModalidade();
    }
}


$( document ).ready(function() {
	M001.init();
});

